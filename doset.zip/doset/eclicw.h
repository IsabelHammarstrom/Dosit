void eclicw_enable(int irqn, int level, int priority, void (*pISR)(void));
