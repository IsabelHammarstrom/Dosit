#include "gd32vf103.h"
#include "drivers.h"
#include "lcd.h"
#include "rtc.h"
#include "delay.h"



void rtcInit(void){
   rcu_periph_clock_enable(RCU_PMU);                                   // enable power managemenet unit - perhaps enabled by default
   pmu_backup_write_enable();                                           // enable write access to the registers in the backup domain
   rcu_periph_clock_enable(RCU_BKPI);                                   // enable backup domain
   
   bkp_deinit();                                                        // reset backup domain registers
   // set the results of a previous calibration procedure
   // bkp_rtc_calibration_value_set(x);

   // setup RTC
   // enable external low speed XO
   //rcu_osci_on(RCU_LXTAL);
   if (rcu_osci_stab_wait(RCU_HXTAL)) {
     // use external low speed oscillaotr, i.e. 32.768 kHz
     rcu_rtc_clock_config(RCU_RTCSRC_HXTAL_DIV_128);
     rcu_periph_clock_enable(RCU_RTC);
     // wait until shadow registers are synced from the backup domain
     // over the APB bus
     rtc_register_sync_wait();
     // wait until shadow register changes are synced over APB
     // to the backup doamin
     rtc_lwoff_wait();
     rtc_prescaler_set(62500 - 1);                                                           // prescale to 1 second
     rtc_lwoff_wait();
     rtc_flag_clear(RTC_INT_FLAG_SECOND);
     //rtc_interrupt_enable(RTC_INT_SECOND);
     rtc_lwoff_wait();
   }
}

//////////////////////////////////////////////////////////////////////////////// main  /////////////////////////////////////////////////////////

int main(void){

  int key;
  int lookUpTbl[16]={1,4,7,14,2,5,8,0,3,6,9,15,10,11,12,13};
  int sensorState = 0;                                        // Lägg till en variabel för att hålla reda på sensorns tillstånd

  colinit();                              // Initialize column toolbox
  keyinit();                              // Initialize keyboard toolbox

  Lcd_SetType(LCD_NORMAL);                // or use LCD_INVERTED!
  Lcd_Init();
  LCD_Clear(BLACK);

  rcu_periph_clock_enable(RCU_GPIOB);
  rcu_periph_clock_enable(RCU_GPIOA);

  gpio_init(GPIOA, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3 | GPIO_PIN_2);            // The following two lines initializes the pins connected to the LEDs on the longan board as outputs with push-pull.   
  gpio_init(GPIOB, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8);


  while (1) {
    LCD_WR_Queue();                                 // Manage LCD com queue!  
    colset();                                       // ... Keyboard
    key=keyscan();
    
//////////////////////////////////////////////////////////////////////////////// Hantering av sensorer /////////////////////////////////////////////////////////
    //gpio_bit_write(GPIOA, GPIO_PIN_2, 1);                   //lysdiod för sensorn
 /**   if (gpio_input_bit_get(GPIOB, GPIO_PIN_8) == 0) {
            if (sensorState == 0) {
                // Sensor gick från av till på
                sensorState = 1;
                gpio_bit_write(GPIOA, GPIO_PIN_3, 1);
                LCD_Fill(0, 0, 160, 80, BLACK);
                LCD_ShowStr(10, 60, "Medicin is left", RED, TRANSPARENT);
            }
        } else {
            if (sensorState == 1) {
                // Sensor gick från på till av
                sensorState = 0;
                gpio_bit_write(GPIOA, GPIO_PIN_3, 0);
                LCD_Fill(0, 0, 160, 80, BLACK);
                LCD_ShowStr(10, 60, "Medicin is token", RED, TRANSPARENT);
            }
        } 
   */ 
//////////////////////////////////////////////////////////////////////////////// Hantering av sensorer version 1 /////////////////////////////////////////////////////////
    if (gpio_input_bit_get(GPIOB, GPIO_PIN_8) == 0) {     //Läsningen är "0" (eller låg), vilket tyder på att sensorn är på.
    
      //gpio_bit_write(GPIOA, GPIO_PIN_4, 1);                 // högtalaren på
      gpio_bit_write(GPIOA, GPIO_PIN_3, 1);                 // Lysdioden sätts på
      LCD_Clear(BLACK);
      LCD_ShowStr(10, 60, "Medicin is left", RED, TRANSPARENT);

    } 
    else {                                     //Läsningen är "1" (eller hög), vilket tyder på att sensorn är av.
      //gpio_bit_write(GPIOA, GPIO_PIN_4, 0);         // högtalaren av
      gpio_bit_write(GPIOA, GPIO_PIN_3, 0);         // Stäng av lysdioden
      LCD_Clear(BLACK);
      LCD_ShowStr(10, 60, "Medicin is token", RED, TRANSPARENT);
    }

///////////////////////////////////////////////////////////////////////////////////// RTC /////////////////////////////////////////////////////////
  /** 
    rtcInit(); // Initiera RTC

    // Hämta RTC-tiden och konvertera den till timmar, minuter och sekunder
    uint32_t rtc_time = rtc_counter_get();                            // Hämta RTC-tiden
    uint32_t hours = (rtc_time / 3600);                          // Beräkna antal timmar på dygnet
    uint32_t minutes = (rtc_time % 3600) / 60;                          // Beräkna antal minuter
    uint32_t seconds = (rtc_time % 3600) % 60;                                 // Beräkna antal sekunder

                                                                                
    char time_string[20];                                             // Konvertera RTC-tiden till en sträng
    snprintf(time_string, sizeof(time_string), "Time: %02d:%02d:%02d", hours, minutes, seconds);
    LCD_Fill(10, 30, 160, 50, BLACK);
    LCD_ShowStr(10, 30, time_string, RED, TRANSPARENT);

    rtc_counter_set(rtc_time + 1);                                    // Uppdatera RTC-räknaren med den aktuella tiden
*/
/////////////////////////////////////////////////////////////////////////// Manuellhantering av luckor /////////////////////////////////////////////////////////

    switch (key) {
      case 0: {
        gpio_bit_write(GPIOA, GPIO_PIN_0, 0);
        gpio_bit_write(GPIOA, GPIO_PIN_1, 1);
        gpio_bit_write(GPIOA, GPIO_PIN_3, 1);             //Lysdioden sätts på
        
        LCD_Clear(BLACK);
        LCD_ShowStr(10, 10, "MON open", RED, TRANSPARENT);
        delay_1ms(2000);
        break;
      }     
      case 1:{
        gpio_bit_write(GPIOA, GPIO_PIN_1, 0);
        gpio_bit_write(GPIOA, GPIO_PIN_0, 1);
        gpio_bit_write(GPIOA, GPIO_PIN_3, 1);             //Lysdioden sätts på

        LCD_Clear(BLACK);
        LCD_ShowStr(10, 10, "TUE open", RED, TRANSPARENT);
        delay_1ms(2000);
        break;
      }
      case 2:{       
        gpio_bit_write(GPIOA, GPIO_PIN_0, 0);
        gpio_bit_write(GPIOA, GPIO_PIN_1, 0);           // alla öppnas 
        gpio_bit_write(GPIOA, GPIO_PIN_3, 1);           //Lysdioden sätts på

        LCD_Clear(BLACK);
        LCD_ShowStr(10, 10, "Open all days", RED, TRANSPARENT);
        delay_1ms(2000);
        break;
      }
      case 3:{
        gpio_bit_write(GPIOA, GPIO_PIN_0, 1);              // alla stängs
        gpio_bit_write(GPIOA, GPIO_PIN_1, 1);
        gpio_bit_write(GPIOA, GPIO_PIN_3, 0);             //Lysdioden kopplas av
        
        LCD_Clear(BLACK);
        LCD_ShowStr(10, 10, "Close all days", RED, TRANSPARENT);
        delay_1ms(2000);
        break;
      }
    }         
  }
}