/*!
    \file  rtc.h
    \brief headfile of RTC check and config,time_show and time_adjust function

    \version 2019-6-5, V1.0.0, firmware for GD32VF103
*/
#ifndef __RTC_H
#define __RTC_H

#include "gd32vf103.h"
#include <stdio.h>

void rtc_configuration(void);
uint32_t time_regulate(void);
void time_adjust(void);
void time_display(uint32_t timevar);
void time_show(void);
uint8_t usart_scanf(uint32_t value);

#endif /* __RTC_H */
